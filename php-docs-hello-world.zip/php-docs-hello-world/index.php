<?php
 $response_payload_json = $_REQUEST["paymentResponse"];
 
print_r($response_payload_json);
 